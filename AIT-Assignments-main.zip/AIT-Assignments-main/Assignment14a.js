let list = []
for(let i=1;i<=50;i++)
{
    list.push(i);
    
}
console.log(list);