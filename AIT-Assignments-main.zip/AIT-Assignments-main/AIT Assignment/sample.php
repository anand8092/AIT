<html>
    <body>
        <h1>My First PHP Page</h1>
        <?php
            print "Hello"
        ?>        
    </body>
</html> 

